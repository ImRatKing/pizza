const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));

// Health check for hosts
app.get('/health', (req, res) => res.send('ok'));

let players = {};
let bullets = [];

wss.on('connection', (ws) => {
  const id = Math.random().toString(36).substr(2, 9);
  players[id] = { x: 300, y: 300, hp: 100 };

  ws.send(JSON.stringify({ type: 'init', id }));

  ws.on('message', (msg) => {
    try {
      const data = JSON.parse(msg);
      if (data.type === 'move') {
        players[id].x = data.x;
        players[id].y = data.y;
      }
      if (data.type === 'shoot') {
        bullets.push({ x: data.x, y: data.y, dx: data.dx, dy: data.dy, owner: id });
      }
    } catch (e) { }
  });

  ws.on('close', () => {
    delete players[id];
  });
});

setInterval(() => {
  // update bullets
  bullets.forEach((b, i) => {
    b.x += b.dx * 5;
    b.y += b.dy * 5;

    for (const pid in players) {
      if (pid !== b.owner) {
        const p = players[pid];
        if (Math.abs(p.x - b.x) < 20 && Math.abs(p.y - b.y) < 20) {
          p.hp -= 10;
          bullets.splice(i, 1);
          if (p.hp <= 0) p.hp = 100;
        }
      }
    }
  });

  const state = { type: 'state', players, bullets };
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(state));
    }
  });
}, 1000 / 30);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
