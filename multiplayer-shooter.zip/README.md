# Multiplayer Shooter

A simple WebSocket-based multiplayer top-down shooter.

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000 in multiple tabs to test.

## Deploy

Use one of these:

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template)
